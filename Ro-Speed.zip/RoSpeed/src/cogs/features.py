import requests
import numpy as np
import orjson as json
from concurrent.futures import ThreadPoolExecutor
from requests.adapters import HTTPAdapter
from requests.packages.urllib3.util.retry import Retry
from requests.exceptions import RequestException
from requests_futures.sessions import FuturesSession

roblox_cookie = {".ROBLOSECURITY": "_|WARNING:-DO-NOT-SHARE-THIS.--Sharing-this-will-allow-someone-to-log-in-as-you-and-to-steal-your-ROBUX-and-items.|_6F9D86B3934A73E548AAFDF219A327E4262A16750AF8EC377801F19E81FA29FB3AD215B9A77EBE042101C318FF5AF643D315ADBA315C9E2700C260DE3A2745BBED0DEC6FE46F368EDA93724B3C422C8EAB711D6CBB06F60F7FD6590B09FD70605617B69BF2C74BC4B3D2796ABFEFA494CD10ABD0D50D0A06409AAB800128F7B015359D75D0F15F196F128D380AB824960AEA96CBB68E1637A491504B859A09179F2C37610AAD2F85108AAC068007C5F55345B576C5414085F23660CD6F2DAB1BD80A683AAF4D5EBC34DA5C3563CD26FE0338EAA0D33AA7D730B22351F61517FD4CC005CBD2CA6716DD414E79982C1D3936EA1D1CB7975543AEA99F2E4B824A895D8F378DFB37C5BDFCB5B4BCEF6A6B690BC997990A45DE8FCD57AFB212DFF527E572C86B96628094019CF0DCD270AE76E59461806390BC24A308E43F78041163CEEA27301E6628BB75B42FBF656803B69E591D7E366521234EE5153DDB25FEADCA4D8FA82779379F1E1C7434908FF96A6FE9A7D45386AF063B0E0C8E7388F7F76E7401051984F61B2525C7E0548F64E4F6605C3634EA7E4CB936B01F5B4E1160BFFE00BB562D0ED3FC72E6C71C64934E2F0E31F63102A06C1B423E30C15C49E3D7AEFCFFB34230EAE021D83EF51EA112AEF7071B"}

def retry_session(
    retries=3,
    backoff_factor=0.3,
    status_forcelist=(500, 502, 504),
    session=None,
):
    """
    retry session function that retries a request in case of connection errors or status codes
    """
    session = session or requests.Session()
    retry = Retry(
        total=retries,
        read=retries,
        connect=retries,
        backoff_factor=backoff_factor,
        status_forcelist=status_forcelist,
    )
    adapter = HTTPAdapter(max_retries=retry)
    session.mount("http://", adapter)
    session.mount("https://", adapter)
    return session

def get_page(url):
    try:
        response = retry_session().get(url)
        check = response.json()
        if "data" in check:
            clothings = np.array(check['data'])
        else:
            clothings = np.array([])

        if "nextPageCursor" in check and check['nextPageCursor']:
            return clothings, check['nextPageCursor']
        else:
            return clothings, ""
    except RequestException as e:
        print(f"Error requesting page {url}: {e}")
        return np.array([]), ""

def fclothings(id):
    clothings = 0
    cursor = None


    url = f"https://catalog.roblox.com/v1/search/items/details?Category=3&CreatorTargetId={id}&CreatorType=2&Limit=30"
    clothings_data, cursor = get_page(url)
    clothings += len(clothings_data)


    while cursor:
        urls = [
            f"https://catalog.roblox.com/v1/search/items/details?Category=3&CreatorTargetId={id}&CreatorType=2&Limit=30&cursor={cursor}" for _ in range(10)
        ]
        with ThreadPoolExecutor(max_workers=10) as executor:
            results = list(executor.map(get_page, urls))

        for result in results:
            clothings_data, cursor = result
            clothings += len(clothings_data)

    return clothings

def frobux(id):
    global roblox_cookie
    
    with ThreadPoolExecutor(max_workers=10) as executor:
        retries = Retry(total=5, backoff_factor=1, status_forcelist=[502, 503, 504])
        session = requests.Session()
        session.mount('https://', HTTPAdapter(max_retries=retries))
        try:
            future = executor.submit(session.get, f'https://economy.roblox.com/v1/groups/{id}/currency', cookies=roblox_cookie, timeout=5)
        except RequestException as e:
            print(e)
            return 0
        
        try:
            response = future.result()
            data = json.loads(response.text)
            if "robux" in data:
                robux = data.get("robux", 0)
            else:
                robux = 0
        except RequestException as e:
            print(e)
            return 0
    
    return robux

def fgamevisits(id):
    retries = Retry(total=5, backoff_factor=1, status_forcelist=[502, 503, 504])
    session = requests.Session()
    session.mount('https://', HTTPAdapter(max_retries=retries))

    with ThreadPoolExecutor(max_workers=10) as executor:
        future = executor.submit(session.get, f'https://games.roblox.com/v2/groups/{id}/games?accessFilter=All&sortOrder=Asc&limit=100', timeout=5)

        try:
            response = future.result()
            os = response.json()
            if "data" in os:
                data = os["data"]
            else:
                data = 0

        except requests.exceptions.RequestException as e:
            print(e)
            return 0

    if not data:
        return 0

    visits = np.array([game["placeVisits"] for game in data])
    total_visits = np.sum(visits)
    
    return total_visits

def groupimage(id):
    # Create a session with retries enabled
    session = FuturesSession()
    retry = Retry(connect=3, backoff_factor=0.5, status_forcelist=[502, 503, 504])
    adapter = HTTPAdapter(max_retries=retry)
    session.mount('https://', adapter)

    # Send the request asynchronously and return a Future object
    future = session.get(f'https://thumbnails.roblox.com/v1/groups/icons?groupIds={id}&size=150x150&format=Png&isCircular=false', timeout=5)

    # Wait for the request to complete and handle any errors that may occur
    try:
        response = future.result()
        icon_url = response.json()
        if "data" in icon_url and len(icon_url["data"]) > 0:
            image = icon_url["data"][0]["imageUrl"]
        else:
            image = ""
    except RequestException as e:
        print(e)
        image = ""
    return image