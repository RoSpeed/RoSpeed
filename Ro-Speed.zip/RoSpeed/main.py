import time
from src.threading import *

if __name__ == "__main__":
    main = RoSpeed()
    main.main()
    startMain()